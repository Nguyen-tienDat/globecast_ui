
import 'package:flutter/foundation.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:speech_to_text/speech_recognition_result.dart';
import 'package:speech_to_text/speech_recognition_error.dart';
import 'translation_service.dart';

class MultilingualSpeechService extends ChangeNotifier {
  // Speech instance
  late stt.SpeechToText _speech;
  bool _isListening = false;
  bool _isAvailable = false;
  String _text = '';
  String _lastWords = '';
  double _confidence = 1.0;
  String _currentLocale = 'en_US';

  // Translation service
  TranslationService? _translationService;

  // STT control flags
  bool _isSTTEnabled = false;
  bool _continuousMode = false;
  int _pauseDuration = 2;

  // Language settings
  String _detectedLanguage = 'en';
  bool _autoDetectLanguage = true;

  // Error handling
  bool _isInitializing = false;
  String? _lastError;

  // Current user context
  String? _currentUserId;
  String? _currentUserName;

  // Supported languages mapping
  final Map<String, String> _supportedLanguages = {
    'en': 'English',
    'vi': 'Tiếng Việt',
    'zh': '中文',
    'ja': '日本語',
    'ko': '한국어',
    'es': 'Español',
    'fr': 'Français',
    'de': 'Deutsch',
    'ru': 'Русский',
    'ar': 'العربية',
  };

  final Map<String, String> _speechLocales = {
    'en': 'en_US',
    'vi': 'vi_VN',
    'zh': 'zh_CN',
    'ja': 'ja_JP',
    'ko': 'ko_KR',
    'es': 'es_ES',
    'fr': 'fr_FR',
    'de': 'de_DE',
    'ru': 'ru_RU',
    'ar': 'ar_SA',
  };

  // Getters
  bool get isListening => _isListening;
  bool get isAvailable => _isAvailable;
  bool get isSTTEnabled => _isSTTEnabled;
  bool get isInitializing => _isInitializing;
  String get text => _text;
  String get lastWords => _lastWords;
  double get confidence => _confidence;
  String get detectedLanguage => _detectedLanguage;
  bool get autoDetectLanguage => _autoDetectLanguage;
  bool get continuousMode => _continuousMode;
  Map<String, String> get supportedLanguages => _supportedLanguages;
  String? get lastError => _lastError;

  // Translation getters
  bool get isTranslationEnabled => _translationService != null;
  String get translatedText => '';
  String get sourceLanguage => _detectedLanguage;
  String get targetLanguage => _translationService?.userPreference?.displayLanguage ?? 'en';
  bool get isTranslating => false;

  MultilingualSpeechService() {
    if (kDebugMode) {
      print('🎤 Multilingual Speech Service created');
    }
  }

  // Set translation service
  void setTranslationService(TranslationService translationService) {
    _translationService = translationService;
    if (kDebugMode) {
      print('🔗 Translation service connected');
    }
  }

  // Set user context
  void setUserContext(String userId, String userName) {
    _currentUserId = userId;
    _currentUserName = userName;
    if (kDebugMode) {
      print('👤 User context set: $userName ($userId)');
    }
  }

  // Enable STT
  Future<void> enableSTT() async {
    if (_isSTTEnabled || _isInitializing) return;

    _isInitializing = true;
    _lastError = null;
    notifyListeners();

    try {
      if (kDebugMode) {
        print('🎤 Enabling Speech-to-Text...');
      }

      _speech = stt.SpeechToText();
      _isAvailable = await _speech.initialize(
        onStatus: _onSpeechStatus,
        onError: _onSpeechError,
        debugLogging: kDebugMode,
      );

      if (_isAvailable) {
        _isSTTEnabled = true;

        // Set language from user preference
        if (_translationService?.userPreference != null) {
          final speakingLang = _translationService!.userPreference!.speakingLanguage;
          _detectedLanguage = speakingLang;
          _currentLocale = _speechLocales[speakingLang] ?? 'en_US';
        }

        if (kDebugMode) {
          print('✅ STT enabled successfully');
        }
      } else {
        _lastError = 'Speech recognition not available';
        if (kDebugMode) {
          print('❌ STT not available');
        }
      }
    } catch (e) {
      _lastError = e.toString();
      _isAvailable = false;
      _isSTTEnabled = false;
      if (kDebugMode) {
        print('❌ Error enabling STT: $e');
      }
    } finally {
      _isInitializing = false;
      notifyListeners();
    }
  }

  // Disable STT
  Future<void> disableSTT() async {
    if (!_isSTTEnabled) return;

    try {
      if (_isListening) {
        await stopListening();
      }

      _isSTTEnabled = false;
      _isAvailable = false;
      _lastError = null;

      if (kDebugMode) {
        print('🔇 STT disabled');
      }

      notifyListeners();
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error disabling STT: $e');
      }
    }
  }

  // Start listening - FIXED to prevent auto-toggle
  Future<void> startListening({
    String? locale,
    bool continuous = false,
  }) async {
    // Enable STT if not enabled
    if (!_isSTTEnabled) {
      await enableSTT();
    }

    // Check if can start
    if (_isListening || !_isAvailable || !_isSTTEnabled || _isInitializing) {
      if (kDebugMode) {
        print('⚠️ Cannot start listening: listening=$_isListening, available=$_isAvailable, enabled=$_isSTTEnabled');
      }
      return;
    }

    try {
      if (kDebugMode) {
        print('🎤 Starting speech recognition...');
      }

      // Set locale
      if (_translationService?.userPreference != null) {
        final speakingLang = _translationService!.userPreference!.speakingLanguage;
        _currentLocale = _speechLocales[speakingLang] ?? 'en_US';
        _detectedLanguage = speakingLang;
      } else if (locale != null) {
        _currentLocale = _speechLocales[locale] ?? 'en_US';
        _detectedLanguage = locale;
      }

      _continuousMode = continuous;
      _text = '';
      _lastWords = '';
      _lastError = null;

      // Start listening with proper configuration
      await _speech.listen(
        onResult: _onSpeechResult,
        listenFor: const Duration(seconds: 30),
        pauseFor: Duration(seconds: _pauseDuration),
        partialResults: true,
        localeId: _currentLocale,
        onSoundLevelChange: _onSoundLevelChange,
      );

      _isListening = true;
      notifyListeners();

      if (kDebugMode) {
        print('🎤 Started listening in $_currentLocale');
      }
    } catch (e) {
      _lastError = e.toString();
      _isListening = false;
      notifyListeners();

      if (kDebugMode) {
        print('❌ Error starting speech recognition: $e');
      }
    }
  }

  // Stop listening
  Future<void> stopListening() async {
    if (!_isListening) return;

    try {
      if (kDebugMode) {
        print('🛑 Stopping speech recognition...');
      }

      await _speech.stop();
      _isListening = false;
      _continuousMode = false;

      // Save final result if exists
      if (_text.isNotEmpty) {
        await _saveTranscriptionToDatabase(true);
      }

      notifyListeners();

      if (kDebugMode) {
        print('🛑 Stopped listening');
      }
    } catch (e) {
      _isListening = false;
      notifyListeners();

      if (kDebugMode) {
        print('❌ Error stopping speech recognition: $e');
      }
    }
  }

  // Toggle listening - FIXED
  Future<void> toggleListening() async {
    if (_isListening) {
      await stopListening();
    } else {
      await startListening(continuous: false);
    }
  }

  // Speech status callback - FIXED
  void _onSpeechStatus(String status) {
    if (kDebugMode) {
      print('🔄 Speech status: $status');
    }

    // Update listening state based on status
    final wasListening = _isListening;

    switch (status) {
      case 'listening':
        _isListening = true;
        break;
      case 'notListening':
      case 'done':
      case 'doneNoResult':
        _isListening = false;

        // Save final result
        if (status == 'done' && _text.isNotEmpty) {
          _saveTranscriptionToDatabase(true);
        }
        break;
    }

    // Only notify if state changed
    if (wasListening != _isListening) {
      notifyListeners();
    }
  }

  // Speech error callback
  void _onSpeechError(SpeechRecognitionError error) {
    if (kDebugMode) {
      print('❌ Speech error: ${error.errorMsg}');
    }

    _lastError = error.errorMsg;
    _isListening = false;
    notifyListeners();
  }

  // Speech result callback - FIXED to show on screen
  void _onSpeechResult(SpeechRecognitionResult result) {
    _text = result.recognizedWords;
    _lastWords = result.recognizedWords;
    _confidence = result.confidence;

    if (kDebugMode) {
      print('🎯 Speech result: "$_text" (final: ${result.finalResult}, confidence: ${(_confidence * 100).toInt()}%)');
    }

    // Save to database immediately for real-time display
    if (_text.isNotEmpty &&
        _translationService != null &&
        _currentUserId != null &&
        _currentUserName != null) {

      // Save both interim and final results
      _saveTranscriptionToDatabase(result.finalResult);
    }

    notifyListeners();
  }

  // Save transcription to database
  Future<void> _saveTranscriptionToDatabase(bool isFinal) async {
    if (_translationService == null ||
        _currentUserId == null ||
        _currentUserName == null ||
        _text.trim().isEmpty) return;

    try {
      await _translationService!.saveSpeechTranscription(
        speakerId: _currentUserId!,
        speakerName: _currentUserName!,
        originalText: _text,
        originalLanguage: _detectedLanguage,
        isFinal: isFinal,
        confidence: _confidence,
      );

      if (kDebugMode) {
        print('💾 Transcription saved: $_text (final: $isFinal)');
      }

      // Clear text after saving final result
      if (isFinal) {
        Future.delayed(const Duration(milliseconds: 500), () {
          _text = '';
          _lastWords = '';
          notifyListeners();
        });
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error saving transcription: $e');
      }
    }
  }

  // Sound level callback
  void _onSoundLevelChange(double level) {
    // Can be used for voice activity indicator
  }

  // Set speaking language
  void setSpeakingLanguage(String languageCode) {
    _detectedLanguage = languageCode;
    _currentLocale = _speechLocales[languageCode] ?? 'en_US';
    notifyListeners();

    if (kDebugMode) {
      print('🗣️ Speaking language set to: ${_supportedLanguages[languageCode]}');
    }
  }

  // Get speech status
  String getSpeechStatus() {
    if (_isInitializing) return 'initializing';
    if (!_isSTTEnabled) return 'disabled';
    if (!_isAvailable) return 'unavailable';
    if (_isListening) return 'listening';
    if (_lastError != null) return 'error';
    return 'ready';
  }

  // Clear text
  void clearText() {
    _text = '';
    _lastWords = '';
    _confidence = 1.0;
    notifyListeners();
  }

  @override
  void dispose() {
    if (kDebugMode) {
      print('🧹 Disposing Multilingual Speech Service...');
    }

    if (_isListening) {
      _speech.stop();
    }

    _isSTTEnabled = false;
    _isAvailable = false;
    _isListening = false;
    _translationService = null;

    super.dispose();
  }
}